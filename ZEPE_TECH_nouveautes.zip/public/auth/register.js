const form = document.querySelector('#regForm');
const msg = document.querySelector('#regMessage');
const ref = (new URLSearchParams(location.search).get('ref') || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 16);

if (ref) {
  fetch('/api/referrer?ref=' + encodeURIComponent(ref))
    .then(r => r.json())
    .then(d => {
      if (d.name) {
        document.querySelector('#inviter').textContent = d.name;
        document.querySelector('#invite').classList.remove('hidden');
      }
    }).catch(() => {});
}

form.addEventListener('submit', async e => {
  e.preventDefault();
  msg.className = '';
  const f = form.elements;
  const pw = f.password.value;
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(f.email.value.trim())) return fail('Adresse e-mail invalide.');
  if (pw.length < 10 || !/[a-z]/.test(pw) || !/[A-Z]/.test(pw) || !/\d/.test(pw)) return fail('Mot de passe : 10 caractères min., avec minuscule, majuscule et chiffre.');
  if (pw !== f.confirm.value) return fail('Les mots de passe ne correspondent pas.');
  if (!f.terms.checked) return fail('Vous devez accepter les conditions.');
  msg.textContent = 'Patientez…';
  try {
    const r = await fetch('/api/register', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: f.name.value, email: f.email.value, password: pw, ref })
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.error || 'Une erreur est survenue.');
    location.href = '/dashboard.html';
  } catch (err) { fail(err.message); }
});
function fail(t) { msg.textContent = t; msg.className = 'error'; }
